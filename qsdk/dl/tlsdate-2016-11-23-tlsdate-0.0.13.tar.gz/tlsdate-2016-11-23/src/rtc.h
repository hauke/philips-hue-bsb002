#ifndef RTC_H
#define RTC_H

struct rtc_handle
{
	int fd;
};

#endif /* RTC_H */
