#ifndef	TLSDATE_FMEMOPEN_H
#define	TLSDATE_FMEMOPEN_H

#include <stdio.h>

FILE *fmemopen(void *, size_t, const char *);

#endif  /* TLSDATE_FMEMOPEN_H */
