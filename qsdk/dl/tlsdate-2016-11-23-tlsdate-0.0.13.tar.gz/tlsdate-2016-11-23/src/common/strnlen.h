#ifndef	TLSDATE_STRNLEN_H
#define	TLSDATE_STRNLEN_H

#include <stddef.h>

size_t strnlen(const char *, size_t);

#endif  /* TLSDATE_STRNLEN_H */
