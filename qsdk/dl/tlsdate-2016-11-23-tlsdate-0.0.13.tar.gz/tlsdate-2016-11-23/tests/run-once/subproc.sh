#!/bin/sh
. "$(dirname $0)"/../common.sh
passed
