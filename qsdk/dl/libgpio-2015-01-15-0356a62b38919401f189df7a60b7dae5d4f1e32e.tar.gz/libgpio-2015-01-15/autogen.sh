#!/bin/bash
autoreconf -sif
automake --add-missing

